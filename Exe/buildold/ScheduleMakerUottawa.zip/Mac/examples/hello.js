"use strict";
console.log('Hello, world!');
phantom.exit();
